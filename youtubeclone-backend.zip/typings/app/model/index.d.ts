// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportComment = require('../../../app/model/comment');
import ExportLike = require('../../../app/model/like');
import ExportSubscription = require('../../../app/model/subscription');
import ExportUser = require('../../../app/model/user');
import ExportVideo = require('../../../app/model/video');
import ExportVideoView = require('../../../app/model/video_view');

declare module 'egg' {
  interface IModel {
    Comment: ReturnType<typeof ExportComment>;
    Like: ReturnType<typeof ExportLike>;
    Subscription: ReturnType<typeof ExportSubscription>;
    User: ReturnType<typeof ExportUser>;
    Video: ReturnType<typeof ExportVideo>;
    VideoView: ReturnType<typeof ExportVideoView>;
  }
}
