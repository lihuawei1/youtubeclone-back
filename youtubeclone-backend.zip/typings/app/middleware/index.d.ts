// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAuth = require('../../../app/middleware/auth');
import ExportErrorHandller = require('../../../app/middleware/error_handller');

declare module 'egg' {
  interface IMiddleware {
    auth: typeof ExportAuth;
    errorHandller: typeof ExportErrorHandller;
  }
}
