/**
 * 本地开发得配置文件
 */
'use strict';
const secret = require('./secret');
exports.vod = {
  ...secret.vod,
};

