/**
 * 不保存到git得秘密文件
 */
'use strict';
exports.vod = {
  accessKeyId: 'LTAI5tJy5EV7rvFhmi4Kw8Gr',
  accessKeySecret: 'r0C5pTFGBvm6mmpwtQq1XI8IQgCG8U',
};
