/**
 * 生产环境得配置文件
 */
'use strict';
exports.vod = {
  accessKeyId: process.env.accessKeyId,
  accessKeySecret: process.env.accessKeySecret,
};
